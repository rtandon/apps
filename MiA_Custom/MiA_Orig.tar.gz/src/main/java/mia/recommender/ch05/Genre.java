package mia.recommender.ch05;

interface Genre {

}
