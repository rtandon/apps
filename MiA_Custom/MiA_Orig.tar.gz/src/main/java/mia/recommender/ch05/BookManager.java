package mia.recommender.ch05;

class BookManager {

  private BookManager() {
  }

  static Book lookupBook(long itemID) {
    return null; // dummy implementation
  }

}
